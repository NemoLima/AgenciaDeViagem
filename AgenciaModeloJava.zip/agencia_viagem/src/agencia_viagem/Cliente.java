package agencia_viagem;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class Cliente {
	DecimalFormat preco = new DecimalFormat("#,###.00");
	private static int id;
	private String cpf;
	private String nome;
	private ArrayList<String> destinos = new ArrayList<>();
	private ArrayList<Double> valorReservas = new ArrayList<>();
	private int idCliente;
	private double totalPacote;
	
	public Cliente(String nome, String cpf) {
		Cliente.id++;
		this.idCliente = Cliente.id;
		this.cpf=cpf;
		this.nome=nome;
	}
	
	public void addItinerario(double preco, String cidade) {
		this.destinos.add(cidade);
		this.valorReservas.add(preco);
	}
	
	public void resumoPacote() {
		System.out.println("--------------------------------");
		System.out.println("==========CLIENTE Nº " +this.idCliente+ "==========");
		System.out.println("Nome " + this.nome);
		System.out.println("CPF " + this.cpf);
		System.out.println("--------------------------------");
		
		for (int i=0;i<destinos.size();i++) {
			this.totalPacote += valorReservas.get(i);
			System.out.println(i+1 + " - Destino (desembarque): " +this.destinos.get(i));
			System.out.println("Preço R$ "+this.valorReservas.get(i));
			System.out.println("=================================");
			
		}
		System.out.println("--------------------------------");
		System.out.println("Valor total do pacote: R$"+preco.format(this.totalPacote));
	}
}