package agencia_viagem;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		String cpf, nome, cidade;
		double preco;
		int passagens;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("==========FAZER NOVA RESERVA==========");
		System.out.print("Nome completo: ");
		nome = scanner.nextLine();
		System.out.print("CPF (apenas números): ");
		cpf = scanner.next();
		
		Cliente cliente = new Cliente(nome,cpf);
		
		System.out.print("Informe quantas passagens você pretende comprar (disponibilidade pode variar): ");
		passagens = scanner.nextInt();
			
		for(int i=1; i<=passagens; i++) {
			System.out.print("Informe o(s) destino(s) de interesse: " + i + ": ");
			cidade = scanner.next();
			cidade += scanner.nextLine();
			System.out.print("Informe o valor da passagem " + i + ": R$ ");
			preco = scanner.nextDouble();
			cliente.addItinerario(preco, cidade);
		}
		
		cliente.resumoPacote();
	}
}